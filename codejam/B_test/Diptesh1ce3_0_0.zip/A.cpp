#include <bits/stdc++.h>
using namespace std;
#define rep(i,a,b) for (int i=a;i<=b;i++)
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define F first
#define S second
#define mp make_pair
#define pb push_back
typedef long long ll;
typedef vector<int> vi;
typedef pair<int,int> pii;

const ll mod=1000000007;
ll po(ll a,ll b) {ll res=1%mod;a%=mod;for(;b;b>>=1){if(b&(1LL))res=res*a%mod;a=a*a%mod;}return res;}
ll dist[509][509][30];
vector<int> graph[509];
int n,m,k;
ll minDist[509][30];
class Compare {
public:

    bool operator()(pair<ll,pair<int,int> > &a, pair<ll,pair<int,int> > &b){
        if(a.F<b.F) return true;
        return false;
    }
};

void dijk(int hr){
    priority_queue<pair<ll,pair<int,int> >,vector<pair<ll,pair<int,int> > >, Compare > Q;
    Q.push(mp(0,mp(1,hr)));
    minDist[1][hr]=0;
    int node,tim,nxt;
    ll d;
    while(!Q.empty()){
        d=Q.top().F;
        node=Q.top().S.F;
        tim=Q.top().S.S;
        Q.pop();
        for(int i=0 ; i<graph[node].size() ; i++){
                nxt=graph[node][i];
                if(minDist[nxt][hr]>minDist[node][hr]+dist[node][nxt][tim]){
                        minDist[nxt][hr]=minDist[node][hr]+dist[node][nxt][tim];
                        Q.push(mp(minDist[nxt][hr],mp(nxt,(tim+dist[node][nxt][tim])%24)));
                }
        }
    }
}
void shortest(){
    for(int i=0  ;i<509 ; i++){
        for(int j=0 ; j<24 ; j++){
            minDist[i][j]=mod;
        }
    }
    for(int i=0 ; i<24 ; i++)
        dijk(i);
}
void solve(){
    scanf("%d %d %d",&n,&m,&k);
    for(int i=0 ; i<509 ; i++){
        for(int j=0 ; j<509  ; j++){
            for(int k=0 ; k<24 ; k++){
                dist[i][j][k]=mod;
            }
        }
    }
    int a,b,c;
    for(int i=0 ; i<509 ; i++) graph[i].clear();
    for(int i=1 ; i<=m ; i++){
        scanf("%d %d",&a,&b);
        graph[a].push_back(b);
        graph[b].push_back(a);
        for(int i=0 ; i<24 ; i++){
            scanf("%d",&c);
            dist[b][a][i]=dist[a][b][i]=c;
        }
    }
    shortest();
    int d,s;
    for(int i=1 ; i<=k ; i++){
        scanf("%d %d",&d,&s);
        if(minDist[d][s]==mod)
            printf("-1 ");
        else
            printf("%lld ",minDist[d][s]);
    }
    printf("\n");
}
int main(){
 // freopen("..\\input.txt","r",stdin);
	freopen("A-small-attempt0.in","r",stdin);freopen("A-small-attempt0.out","w",stdout);
//	freopen("A-small-attempt1.in","r",stdin);freopen("A-small-attempt1.out","w",stdout);
//  freopen("A-large.in","r",stdin);
//  freopen("A-large.out","w",stdout);
    int t;
    scanf("%d",&t);
    for(int _i=1 ; _i<=t ; _i++){
        printf("Case #%d: ",_i);
        solve();
    }
    return 0;
}

